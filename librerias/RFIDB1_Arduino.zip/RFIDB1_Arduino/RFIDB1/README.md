# Arduino library for RFID B1 module

This library provide simple interface for RFID B1 modules by Eccel Technology Ltd.
and cover all UART command described in specification for this modules.

## Examples

The library comes with two examples in File > Examples > RFIDB1
- Interface_example - example to show how detect card and read UID
- RFIDB1_ESPxxxx_MQTT - similar to above example but with extra funtions 
                        to send RFID ID TAG via MQTT message, this should 
                        be useful for IOT applications.                                                                   

## Compatible Hardware

This library can be used with UART-B1 module, but it basicly cover UART 
protocol for all B1 modules so can be used with all modules from B1 family.
Example with MQTT will work only one the boards with ESP8266 and ESP32 chips. 

## License
Read LICENSE.txt for further informations on licensing terms.

